package com.example.exquizzite

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
